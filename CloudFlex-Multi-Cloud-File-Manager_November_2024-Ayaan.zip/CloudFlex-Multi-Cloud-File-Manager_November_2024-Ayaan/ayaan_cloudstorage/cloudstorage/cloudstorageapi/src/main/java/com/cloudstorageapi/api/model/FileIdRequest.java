package com.cloudstorageapi.api.model;

public class FileIdRequest {
	private int fileId;

	 

	public int getFileId() {
		return fileId;
	}

	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

}
