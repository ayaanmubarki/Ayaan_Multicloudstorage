package com.cloudstorageapi.api.model;

public class FolderIdRequest {
	private int folderId;

	 

	public int getFolderId() {
		return folderId;
	}

	public void setFolderId(int folderId) {
		this.folderId = folderId;
	}

}
