package com.cloudstorageapi.api.model;

public class StorageUsageIdRequest {
	private int StorageUsageId;

	 

	public int getStorageUsageId() {
		return StorageUsageId;
	}

	public void setStorageUsageId(int StorageUsageId) {
		this.StorageUsageId = StorageUsageId;
	}

}
